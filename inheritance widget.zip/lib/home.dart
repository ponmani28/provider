import 'package:flutter/material.dart';


class stfulexamplState extends StatefulWidget {
  const stfulexamplState({super.key});

  @override
  State<stfulexamplState> createState() => __stfulexamplStateState();
}

class __stfulexamplStateState extends State<stfulexamplState> {
int number = 0;
void increase(){
  setState(() {
    number += 1;
  });
}
void decrease(){
  setState(() {
    number-=1;
  });
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(

        child: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.center,children: [Text("$number"),
          ElevatedButton(onPressed: (){increase();}, child: Text("increase")),ElevatedButton(onPressed: (){decrease();}, child:Text("decrease"))],),
        ),

      ),
    );
  }
}