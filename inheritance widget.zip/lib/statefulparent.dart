import 'package:flutter/material.dart';
import 'package:intern/statelesschild.dart';

class statefulparent extends StatefulWidget {
  const statefulparent({super.key});

  @override
  State<statefulparent> createState() => _statefulparentState();
}

class _statefulparentState extends State<statefulparent> {

int _number = 0;
void _increase(){
  setState(() {
    _number += 1;
  });
}
void _decrease(){
  setState(() {
    _number-=1;
  });
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: statelesschild(number: _number, increase: _increase, decrease: _decrease));
  }
}