import 'package:flutter/material.dart';

class statelesschild extends StatelessWidget {
 final int number;
 final Function() increase;
 final Function() decrease;
statelesschild({super.key, required this.number, required this.increase, required this.decrease});

  @override
  Widget build(BuildContext context) {
    return  Container(child: Row(
      children: [
        Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center,children: [
        
              Text("$number"),
              ElevatedButton(onPressed: (){increase();}, child: Text("increase"),),
               ElevatedButton(onPressed: (){decrease();}, child: Text("decrease"),),
        
            ],),
        ),
      ],
    ),) ;
  }
}

//  