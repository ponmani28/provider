import 'package:flutter/material.dart';
import 'package:intern/inherited_example.dart';

import 'inherited_example.dart';

class inheritedexample extends StatefulWidget {
  const inheritedexample({super.key});

  @override
  State<inheritedexample> createState() => _inheritedexampleState();
}

class _inheritedexampleState extends State<inheritedexample> {

  int number = 0;
  @override
  Widget build(BuildContext context) {
    return 
       Scaffold(
         body: Container(child: Row(
          children: [
            Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center,children: [
                    numberinheritedwidget(number, child: nestedwidget()),
                  ElevatedButton(onPressed: (){setState(() {
                    number++;
                  });}, child: Text("increase"),),
                   ElevatedButton(onPressed: (){setState(() {
                     number--;
                   });}, child: Text("decrease"),),
            
                ],),
            ),
          ]),),
       );
      
  }
}



class numberinheritedwidget extends InheritedWidget {
  
  final int number;
  numberinheritedwidget(this.number, {
    Key? key,
    required Widget child, 
  }) : super(key: key, child: child);

 static numberinheritedwidget of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<numberinheritedwidget>()!;
  }

  @override
  bool updateShouldNotify( numberinheritedwidget oldWidget) =>
    number!= oldWidget.number; ///if the number is not equal to the old ,triggering the updatenotify method
  }

 
class nestedwidget extends StatelessWidget {
  const nestedwidget({super.key});

  @override
  Widget build(BuildContext context) {
    int number = numberinheritedwidget.of(context).number;
    return Text("$number");
  }
}