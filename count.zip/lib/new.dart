


import 'package:flutter/material.dart';

class neww extends StatelessWidget {
  const neww({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Wrap(
                children: [
                  Stack(
  children: [
    Container(
      height: 400,
      width: 380,
      color: Colors.cyan,
      child: Image.asset(
        "assets/download.jpg",
        fit: BoxFit.cover,
      ),
    ),
     Positioned(
      top: 20, 
      right: 20, 
      child: Icon(
        Icons.archive_outlined,
        color: Colors.black,
        size: 30,
      ),
    ),


    Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Stack(
            alignment: Alignment.topRight,
            children: [
              Container(
                height: 70,
                width: 180,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: Colors.white,
                ),
                child: Column(
                  children: [
                    Text(
                      "saints",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "lawerence",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.blue, // Customize the color of the avatar
                ),
                child: Center(
                  child: Icon(
                    Icons.person,
                    color: Colors.white, // Customize the icon color
                    size: 40, // Adjust the size of the icon
                  ),
                ),
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.all(5),
            height: 70,
            width: 150,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.blueGrey,
            ),
            child: Center(
              child: Text(
                "See More",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    ),
  ],
)

                ],
              ),
              Container(
                height: 300,
                width: 380,
                color: Colors.blueGrey[100],
                child: Padding(
                  padding: const EdgeInsets.all(5),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Text(
                            " 5699k",
                            style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(
                            width: 50,
                          ),
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.blue,
                            ),
                            child: const Center(
                              child: Text("residence"),
                            ),
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Container(
                            child: const Text("3-4 months"),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                      const Row(
                        children: [SizedBox(width: 25,),
                          Icon(
                            Icons.location_on,
                            color: Colors.green,
                          ),
                          Text(
                            "248 Lawerence Hargrave Drive",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                     const SizedBox(width: 10,),
const SizedBox(height: 7,),
const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [SizedBox(width: 25,),
                                  Icon(Icons.bed),
                                  Text("3 beds"),SizedBox(width: 10,),
                                  Icon(Icons.bathtub),
                                  Text("2 bath"),SizedBox(width: 10,),
                                  Icon(Icons.home),
                                  Text("2223m"),
                                ],
                              ),
                            ],
                          ),

                      const SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: 60,
                            width: 300,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white,
                            ),
                            child: const Row(
                              children: [
                                CircleAvatar( backgroundImage: AssetImage("assets/download.jpg"),),SizedBox(width: 5,),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [Text("    ponmani Thangam V",style: TextStyle(fontSize:13,fontWeight: FontWeight.bold),), Text("sales")],
                                ),
                                SizedBox(
                                  width: 60,
                                ),
                                Icon(Icons.message),
                                SizedBox(
                                  width: 5,
                                ),
                                Icon(Icons.call),
                              ],
                            ),
                          ),
                        ],
                      ),SizedBox(height: 10,),
                      const Padding(
                        padding: EdgeInsets.all(10),
                        child: Column(
                          children: [
                            Row(
                              children: [Text("   Lorem ipsum dolor sit amet. Aut maxime ")],
                            ),
                            Row(
                              children: [Text("   Lorem ipsum dolor sit amet. Aut maxime ")],
                            ),
                            Row(
                              children: [Text("   Lorem ipsum dolor sit amet. Aut maxime ")],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.transparent),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.blue,
                  minimumSize: const Size(150, 50),
                ),
                child: const Text('Explore in VR',style: TextStyle(color: Colors.black),),
              ),
              ElevatedButton(
                onPressed: () {
                 
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.green,
                  minimumSize: const Size(150, 50), 
                ),
                child: const Text('Buy'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}