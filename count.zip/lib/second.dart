import 'package:flutter/material.dart';
import 'package:intern/provider.dart';
import 'package:provider/provider.dart';

class second extends StatefulWidget {
   second({super.key, });

  

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  @override
  Widget build(BuildContext context) {
    return Consumer<NumberslistProvider>(
        builder:(context, NumberslistProvider  , child) => Scaffold(
      appBar: AppBar(),
      floatingActionButton: FloatingActionButton(child: Icon(Icons.add),
  
        
        onPressed: (){
          NumberslistProvider.add();
          }
      ,),

      body:   SizedBox(child: Column(children: [
      
      
      
      
            Text(NumberslistProvider.numbers.last.toString(),style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold)),
      
      
            Expanded(
              child: ListView.builder(
              itemCount:NumberslistProvider.numbers.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: ((context, index) {
                return Text(NumberslistProvider.numbers[index].toString(),style: const TextStyle(fontSize: 30,fontWeight: FontWeight.bold),);
              })),
            )
      
        ],),),
      ),
    );
  }
}

// // second.dart
// import 'package:flutter/material.dart';
// import 'package:intern/provider.dart';
// import 'package:provider/provider.dart';

// class Second extends StatefulWidget {
//   Second({Key? key});

//   @override
//   State<Second> createState() => _SecondState();
// }

// class _SecondState extends State<Second> {
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<NumberslistProvider>(
//       builder: (context, numbersProviderModel, child) => Scaffold(
//         appBar: AppBar(),
//         floatingActionButton: FloatingActionButton(
//           child: Icon(Icons.add),
//           onPressed: () {
//             numbersProviderModel.add();
//           },
//         ),
//         body: SizedBox(
//           child: Column(
//             children: [
//               Text(
//                 numbersProviderModel.numbers.last.toString(),
//                 style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
//               ),
//               Expanded(
//                 child: ListView.builder(
//                   itemCount: numbersProviderModel.numbers.length,
//                   scrollDirection: Axis.horizontal,
//                   itemBuilder: ((context, index) {
//                     return Text(
//                       numbersProviderModel.numbers[index].toString(),
//                       style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
//                     );
//                   }),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
