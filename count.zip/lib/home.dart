import 'package:flutter/material.dart';
import 'package:intern/provider.dart';
import 'package:intern/second.dart';
import 'package:provider/provider.dart';

class hom extends StatefulWidget {
   hom({super.key});

  @override
  State<hom> createState() => _homState();
}

class _homState extends State<hom> {


  @override
  Widget build(BuildContext context) {
    return Consumer<NumberslistProvider>(
        builder:(context, numbersprovidermodel, child) => Scaffold(
      appBar: AppBar(),
      floatingActionButton: FloatingActionButton(child: Icon(Icons.add),
  
        
        onPressed: (){
          numbersprovidermodel.add();

          }
      ,),

      body:   SizedBox(child: Column(children: [
      
      
      
      
            Text(numbersprovidermodel.numbers.last.toString(),style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold)),
      
      
            Expanded(
              child: ListView.builder(
              itemCount: numbersprovidermodel.numbers.length,
              itemBuilder: ((context, index) {
                return Text(numbersprovidermodel.numbers[index].toString(),style: const TextStyle(fontSize: 30,fontWeight: FontWeight.bold),);
              })),
            ),ElevatedButton(onPressed: (){Navigator.of(context).push(MaterialPageRoute(builder: (context) => second()));}, child: Text("go to"))
      
        ],),),
      
        )  
    );
  }
}

// home.dart
// import 'package:flutter/material.dart';
// import 'package:intern/provider.dart';
// import 'package:intern/second.dart';
// import 'package:provider/provider.dart';

// class Hom extends StatefulWidget {
//   Hom({Key? key});

//   @override
//   State<Hom> createState() => _HomState();
// }

// class _HomState extends State<Hom> {
//   @override
//   Widget build(BuildContext context) {
//     return Consumer<NumberslistProvider>(
//       builder: (context, numbersProviderModel, child) => Scaffold(
//         appBar: AppBar(),
//         floatingActionButton: FloatingActionButton(
//           child: Icon(Icons.add),
//           onPressed: () {
//             numbersProviderModel.add();
//           },
//         ),
//         body: SizedBox(
//           child: Column(
//             children: [
//               Text(
//                 numbersProviderModel.numbers.last.toString(),
//                 style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
//               ),
//               Expanded(
//                 child: ListView.builder(
//                   itemCount: numbersProviderModel.numbers.length,
//                   itemBuilder: ((context, index) => Text(
//                       numbersProviderModel.numbers[index].toString(),
//                       style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
//                     )),
//                 ),
//               ),
//               ElevatedButton(
//                 onPressed: () {
//                   Navigator.of(context).push(MaterialPageRoute(builder: (context) => Second()));
//                 },
//                 child: Text("Go to Second Screen"),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
