


import 'package:flutter/material.dart';

class neww extends StatelessWidget {
  const neww({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Wrap(
                children: [
                  Card(
  child: Stack(
    children: [
      Container(
        height: 400,
        width: 380,
        color: Colors.cyan,
        child: Image.asset(
          "assets/download.jpg",
          fit: BoxFit.cover,
        ),
      ),
      Positioned(
        bottom: 0,
        left: 0,
        right: 0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 70,
              width: 180,decoration: BoxDecoration(borderRadius: BorderRadius.circular(30),color: Colors.white),
              child: const Column(
                children: [
                  Text("saints",style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold ),),
                  Text("lawerence",style: TextStyle(fontSize: 20,fontWeight:FontWeight.bold)),
                ],
              ),
            ),
            Container(padding: const EdgeInsets.all(5),
              height: 70,
              width: 150,
               
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),color: Colors.blueGrey,),child: const Center(child: Text("See More",style: TextStyle(color: Colors.white),)),// Adjust opacity and color
              
            ),
          ],
        ),
      ),
    ],
  ),
)

                ],
              ),
              Container(
                height: 300,
                width: 380,
                color: Colors.blueGrey[100],
                child: Padding(
                  padding: const EdgeInsets.all(5),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const Text(
                            " 5699k",
                            style: TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(
                            width: 50,
                          ),
                          Container(
                            child: const Center(
                              child: Text("residence"),
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.blue,
                            ),
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Container(
                            child: const Text("3-4 months"),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                      const Row(
                        children: [SizedBox(width: 13,),
                          Icon(
                            Icons.location_on,
                            color: Colors.green,
                          ),
                          Text(
                            "248 Lawerence Hargrave Drive",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                     const SizedBox(width: 7,),
const SizedBox(height: 7,),
const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [SizedBox(width: 15,),
                                  Icon(Icons.bed),
                                  Text("3 beds"),
                                  Icon(Icons.bathtub),
                                  Text("2 bath"),
                                  Icon(Icons.home),
                                  Text("2223m"),
                                ],
                              ),
                            ],
                          ),

                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: 60,
                            width: 300,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white,
                            ),
                            child: const Row(
                              children: [
                                CircleAvatar( backgroundImage: AssetImage("assets/download.jpg"),),SizedBox(width: 2,),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [Text("ponmani"), Text("sales")],
                                ),
                                SizedBox(
                                  width: 145,
                                ),
                                Icon(Icons.message),
                                SizedBox(
                                  width: 5,
                                ),
                                Icon(Icons.call),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const Padding(
                        padding: EdgeInsets.all(10),
                        child: Column(
                          children: [
                            Row(
                              children: [Text("   Lorem ipsum dolor sit amet. Aut maxime ")],
                            ),
                            Row(
                              children: [Text("   Lorem ipsum dolor sit amet. Aut maxime ")],
                            ),
                            Row(
                              children: [Text("   Lorem ipsum dolor sit amet. Aut maxime ")],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
                minimumSize: const Size(150, 50),
              ),
              child: const Text('Explore in VR',style: TextStyle(color: Colors.black),),
            ),
            ElevatedButton(
              onPressed: () {
               
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.green,
                minimumSize: const Size(150, 50), 
              ),
              child: const Text('Buy'),
            ),
          ],
        ),
      ),
    );
  }
}