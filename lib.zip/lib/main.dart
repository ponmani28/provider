

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intern/new.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a blue toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: neww(),
    );
  }
}

// class home extends StatelessWidget {
//   const home({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//      body: Container(child: Padding(
//        padding: const EdgeInsets.all(30),
//        child: SingleChildScrollView(
//          child: Column(
//            children: [
//              const Row(children: [Text("CREATE YOUR ",style: TextStyle(fontSize: 28,fontWeight: FontWeight.bold),)],),
//               const Row(children: [Text("Account",style:TextStyle(fontSize: 28,fontWeight: FontWeight.bold) ,)],),
       
//          const SizedBox(height: 18,) ,
//               const Row(children: [Text("Name",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),)],),const SizedBox(height: 8,),
//                 Row(children: [
//                   Expanded(child: Container(color: Colors.grey[200],height: 50,width:300,child: TextFormField(decoration: const InputDecoration(labelText: "Enter Your Name",border: OutlineInputBorder()),),))
                  
//               ],),
//                 const SizedBox(height: 18,) ,
       
//                const Row(children: [Text("EMAIL",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),)],),const SizedBox(height: 8,),
//               Row(children: [
//                   Expanded(child: Container(color: Colors.grey[200],height: 50,width:300,child: TextFormField(decoration: const InputDecoration(labelText: "Something@gmail.com",border: OutlineInputBorder(),),))
//                   )
//               ],),
       
//                const SizedBox(height: 18,) ,
       
//                const Row(children: [Text("PASSWORD",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),)],),const SizedBox(height: 8,),
//                Row(crossAxisAlignment: CrossAxisAlignment.center,children: [
//                   Expanded(child: Container(color: Colors.grey[200],height: 50,width: 300,child:
//                    TextFormField(obscureText: true,decoration: const InputDecoration(labelText: "Enter Password",border: OutlineInputBorder(),suffixIcon:  Icon(Icons.visibility),),),)),     
                        
//               ],),
//               const SizedBox(height: 18,) ,
       
//        const Row(children: [
//          Expanded(child: Divider()),       
//           Text("OR"),        
//          Expanded(child: Divider()),
//            ]
//        ),
//        const SizedBox(height: 10,),
       
//        Row(children: [Expanded(child: Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey)),height: 60,width:200,child: const Row(mainAxisAlignment: MainAxisAlignment.center,children: [Icon(FontAwesomeIcons.google,color: Colors.red),
//        Text("  CONTINUE WITH GOOGLE",style: TextStyle(fontWeight: FontWeight.bold))],),))],),
//        const SizedBox(height: 10,),
//        Row(children: [Expanded(child: Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey)),height: 60,width:260,child: const Row(mainAxisAlignment: MainAxisAlignment.center,children: [Icon(FontAwesomeIcons.facebook,color: Colors.blue),Text("  CONTINUE WITH FACEBOOK",style: TextStyle(fontWeight: FontWeight.bold))],),))],),
//        const SizedBox(height: 10,),
       
//        Row(children: [Expanded(child: Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey)),
//        height: 60,width:260,
//        child: const Row(mainAxisAlignment: MainAxisAlignment.center,
//        children: [Icon(FontAwesomeIcons.twitter,color: Colors.blue),
//        Text("  CONTINUE WITH TWITTER",style: TextStyle(fontWeight: FontWeight.bold))],),))],),
       
       
//        const SizedBox(height: 18,),
       
//        Row(children: [Expanded(child: 
//        Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
//        border: Border.all(color: Colors.grey),color: Colors.blue[900]),
//        height: 60,width:260,
//        child: const Row(mainAxisAlignment: MainAxisAlignment.center,
//        children: [
//        Text("CONTINUE",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white))],),))],),
           
//            const SizedBox(height: 10,),
//           Row(mainAxisAlignment: MainAxisAlignment.center,children: [Text("Already a member?",style: TextStyle(color: Colors.blue[700],fontWeight: FontWeight.w600),),Text("Log in",style: TextStyle(color: Colors.blue[900],fontWeight: FontWeight.bold),)],)      
           
          
           
//            ]
//            ,
//          ),
//        ),
//      ),),
//     );
//   }}